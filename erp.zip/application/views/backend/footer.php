<!-- begin #footer -->
	<div id="footer" class="footer">
	    &copy; 2017 QRIYO TECHNOLOGY - <a href="http://qriyotechnology.com/" target="_blank">Qriyo Technology</a>
	</div>
<!-- end #footer -->

<!-- begin scroll to top btn -->
	<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top">
		<i class="fa fa-angle-up"></i>
	</a>
<!-- end scroll to top btn -->
</div>
